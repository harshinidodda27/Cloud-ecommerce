import { createClient } from "https://cdn.jsdelivr.net/npm/@supabase/supabase-js/+esm";

const SUPABASE_URL = "https://olxeqapklwxujceaoobz.supabase.co";

const SUPABASE_PUBLISHABLE_KEY = "sb_publishable_FfkF0ltDS6mc1EQP-zT7Xg_CTqJH3Jq ";

export const supabase = createClient(
    SUPABASE_URL,
    SUPABASE_PUBLISHABLE_KEY
); 