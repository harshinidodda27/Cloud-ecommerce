import { supabase } from "./supabase.js";

const registerForm = document.getElementById("registerForm");
const message = document.getElementById("message");

if (registerForm) {
    registerForm.addEventListener("submit", async (event) => {
        event.preventDefault();

        const fullName = document.getElementById("fullName").value.trim();
        const email = document.getElementById("email").value.trim();
        const password = document.getElementById("password").value;
        const confirmPassword =
            document.getElementById("confirmPassword").value;

        if (password !== confirmPassword) {
            message.textContent = "Passwords do not match.";
            message.className = "error";
            return;
        }

        message.textContent = "Creating your account...";

        const { error } = await supabase.auth.signUp({
            email,
            password,
            options: {
                data: {
                    full_name: fullName
                }
            }
        });

        if (error) {
            message.textContent = error.message;
            message.className = "error";
            return;
        }

        message.textContent =
            "Account created successfully! Please check your email to verify your account.";

        message.className = "success";

        registerForm.reset();
    });
} 